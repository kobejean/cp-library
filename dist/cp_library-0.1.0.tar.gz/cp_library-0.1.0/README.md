[![Actions Status](https://github.com/kobejean/cp-library/workflows/verify/badge.svg)](https://github.com/kobejean/cp-library/actions) 
